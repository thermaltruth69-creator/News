package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DailyBriefing
import com.example.data.NewsSource
import com.example.data.NewsStory
import com.example.ui.theme.AmericanRed
import com.example.ui.theme.GoldSeal
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun BriefingManagerScreen(
    onBriefingCreated: (DailyBriefing) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var dateText by remember { mutableStateOf("Thursday, October 22, 2026") }
    var leadHeadline by remember { mutableStateOf("American Small Business Hiring Reaches 18-Month High Amid Regulatory Relief") }
    var leadSummary by remember { mutableStateOf("Independent trade associations and labor department filings show private commercial enterprises expanded payrolls by over 65,000 employees this month.") }
    var leadCategory by remember { mutableStateOf("U.S. Economy") }
    var youtubeUrl by remember { mutableStateOf("https://www.youtube.com/watch?v=dQw4w9WgXcQ") }
    var podcastAudioUrl by remember { mutableStateOf("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3") }
    var pictureUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80") }

    // First story fields
    var storyHeadline by remember { mutableStateOf("Regional Power Grid Investments Bolster Winter Reliability Across 14 States") }
    var storyCategory by remember { mutableStateOf("Infrastructure") }
    var storySummary by remember { mutableStateOf("Public utility commissions approved inter-state transmission upgrades to protect local communities against extreme cold surges.") }
    var sourceName by remember { mutableStateOf("Federal Energy Regulatory Commission (FERC) Filing") }
    var sourceUrl by remember { mutableStateOf("https://www.ferc.gov") }

    var generatedJson by remember { mutableStateOf("") }

    fun buildBriefingObject(): DailyBriefing {
        val story = NewsStory(
            id = "story-" + System.currentTimeMillis(),
            headline = storyHeadline.trim(),
            category = storyCategory.trim(),
            summary = storySummary.trim(),
            picture = pictureUrl.trim(),
            sources = listOf(
                NewsSource(
                    name = sourceName.ifBlank { "Official Public Documentation" },
                    url = sourceUrl.ifBlank { "https://www.usa.gov" }
                )
            ),
            corrections = emptyList()
        )

        return DailyBriefing(
            id = "briefing-" + System.currentTimeMillis(),
            date = dateText.trim(),
            isoDate = "2026-10-22",
            leadHeadline = leadHeadline.trim(),
            leadSummary = leadSummary.trim(),
            leadCategory = leadCategory.trim(),
            youtubeUrl = youtubeUrl.trim(),
            podcastAudioUrl = podcastAudioUrl.trim(),
            pictureUrl = pictureUrl.trim(),
            stories = listOf(story)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("briefing_manager_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Simple Explainer Box for Non-Programmers
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = NavyContainer),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "Help",
                        tint = GoldSeal,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EASY DAILY UPDATE HELPER",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "For James Hastings & James Hastings Sr.:\nType today's news below, tap 'Preview in App' to see how it looks, or tap 'Copy JSON' to paste directly into your briefings.json file on GitHub or Cloudflare Pages without writing any code!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    lineHeight = 22.sp
                )
            }
        }

        Text(
            text = "1. TODAY'S MAIN BRIEFING DETAILS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it },
            label = { Text("Today's Date (e.g. Thursday, October 22, 2026)") },
            modifier = Modifier.fillMaxWidth().testTag("manager_date_input"),
            singleLine = true
        )

        OutlinedTextField(
            value = leadHeadline,
            onValueChange = { leadHeadline = it },
            label = { Text("Lead Top Headline") },
            modifier = Modifier.fillMaxWidth().testTag("manager_lead_headline_input")
        )

        OutlinedTextField(
            value = leadSummary,
            onValueChange = { leadSummary = it },
            label = { Text("Lead Story Summary") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = leadCategory,
                onValueChange = { leadCategory = it },
                label = { Text("Category") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = youtubeUrl,
                onValueChange = { youtubeUrl = it },
                label = { Text("YouTube Video Link") },
                modifier = Modifier.weight(1.5f),
                singleLine = true
            )
        }

        OutlinedTextField(
            value = podcastAudioUrl,
            onValueChange = { podcastAudioUrl = it },
            label = { Text("Podcast Audio URL (NotebookLM MP3/Link)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = pictureUrl,
            onValueChange = { pictureUrl = it },
            label = { Text("Header Photo Image URL") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "2. FIRST VERIFIED STORY & SOURCES",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        OutlinedTextField(
            value = storyHeadline,
            onValueChange = { storyHeadline = it },
            label = { Text("Story Headline") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = storySummary,
            onValueChange = { storySummary = it },
            label = { Text("Story Summary") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = sourceName,
                onValueChange = { sourceName = it },
                label = { Text("Verified Source Name") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = sourceUrl,
                onValueChange = { sourceUrl = it },
                label = { Text("Source Website Link") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Big Action Buttons
        Button(
            onClick = {
                val newBriefing = buildBriefingObject()
                onBriefingCreated(newBriefing)
                Toast.makeText(context, "New briefing loaded into App View!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("preview_briefing_button"),
            colors = ButtonDefaults.buttonColors(containerColor = AmericanRed),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Preview, contentDescription = "Preview")
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Preview Today's Briefing Now In App",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        OutlinedButton(
            onClick = {
                val newBriefing = buildBriefingObject()
                // Format clean JSON snippet
                val storyObj = JSONObject().apply {
                    put("id", newBriefing.stories[0].id)
                    put("headline", newBriefing.stories[0].headline)
                    put("category", newBriefing.stories[0].category)
                    put("summary", newBriefing.stories[0].summary)
                    put("picture", newBriefing.stories[0].picture)
                    val srcArr = JSONArray().apply {
                        put(JSONObject().apply {
                            put("name", newBriefing.stories[0].sources[0].name)
                            put("url", newBriefing.stories[0].sources[0].url)
                        })
                    }
                    put("sources", srcArr)
                    put("corrections", JSONArray())
                }

                val obj = JSONObject().apply {
                    put("id", newBriefing.id)
                    put("date", newBriefing.date)
                    put("isoDate", newBriefing.isoDate)
                    put("leadHeadline", newBriefing.leadHeadline)
                    put("leadSummary", newBriefing.leadSummary)
                    put("leadCategory", newBriefing.leadCategory)
                    put("youtubeUrl", newBriefing.youtubeUrl)
                    put("podcastAudioUrl", newBriefing.podcastAudioUrl)
                    put("videoDuration", "14:20")
                    put("podcastDuration", "18:45")
                    put("pictureUrl", newBriefing.pictureUrl)
                    put("stories", JSONArray().apply { put(storyObj) })
                }

                val jsonFormatted = obj.toString(2)
                generatedJson = jsonFormatted

                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Briefing JSON", jsonFormatted)
                clipboard.setPrimaryClip(clip)

                Toast.makeText(context, "Copied formatted JSON to clipboard!", Toast.LENGTH_LONG).show()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("copy_json_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy JSON", tint = NavyPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Generate & Copy JSON For briefings.json",
                fontWeight = FontWeight.Bold,
                color = NavyPrimary,
                fontSize = 15.sp
            )
        }

        if (generatedJson.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "GENERATED JSON SNIPPET (COPIED):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "To update your site: Open briefings.json on GitHub, paste this at the top of the list inside the brackets [ ... ], and hit Save!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = generatedJson,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                        color = NavyDark
                    )
                }
            }
        }
    }
}
