// True News America — Clean Client-side Application Script
let allBriefings = [];
let currentBriefingIndex = 0;

document.addEventListener('DOMContentLoaded', () => {
  fetch('briefings.json')
    .then(res => res.json())
    .then(data => {
      allBriefings = data;
      renderBriefing(0);
      renderArchive(data);
    })
    .catch(err => {
      console.error('Error loading briefings.json:', err);
      const container = document.getElementById('storiesContainer');
      if (container) {
        container.innerHTML = '<p style="color: red; font-weight: bold;">Could not load briefings.json. Please ensure briefings.json is in the same directory.</p>';
      }
    });
});

function renderBriefing(index) {
  currentBriefingIndex = index;
  const b = allBriefings[index];
  if (!b) return;

  // Masthead & date
  const dateEl = document.getElementById('mastheadDate');
  if (dateEl) dateEl.textContent = b.date;

  // Lead Hero Story
  const heroCat = document.getElementById('heroCategory');
  if (heroCat) heroCat.textContent = (b.leadCategory || 'U.S.').toUpperCase();

  const heroHeadline = document.getElementById('heroHeadline');
  if (heroHeadline) heroHeadline.textContent = b.leadHeadline;

  const heroSummary = document.getElementById('heroSummary');
  if (heroSummary) heroSummary.textContent = b.leadSummary;

  // Video Section
  const videoIframe = document.getElementById('videoIframe');
  if (videoIframe && b.youtubeUrl) {
    let videoId = 'dQw4w9WgXcQ';
    if (b.youtubeUrl.includes('v=')) {
      videoId = b.youtubeUrl.split('v=')[1].split('&')[0];
    }
    videoIframe.src = `https://www.youtube-nocookie.com/embed/${videoId}`;
  }

  // Audio Section
  const audioElement = document.getElementById('podcastAudio');
  if (audioElement && b.podcastAudioUrl) {
    audioElement.src = b.podcastAudioUrl;
  }
  const audioTitle = document.getElementById('podcastTitle');
  if (audioTitle) {
    audioTitle.textContent = `${b.date} — Daily Audio Briefing (${b.podcastDuration || '18:45'})`;
  }

  // Stories List
  const storiesContainer = document.getElementById('storiesContainer');
  if (storiesContainer) {
    storiesContainer.innerHTML = '';
    (b.stories || []).forEach(story => {
      const card = document.createElement('article');
      card.className = 'story-card';

      let sourcesHtml = '';
      if (story.sources && story.sources.length > 0) {
        sourcesHtml = `
          <details class="sources-box">
            <summary>Verified Sources (${story.sources.length}) — Click to Verify</summary>
            <ol class="sources-list-inner">
              ${story.sources.map(s => `<li><a href="${s.url}" target="_blank" rel="noopener noreferrer">${s.name}</a></li>`).join('')}
            </ol>
          </details>
        `;
      }

      let correctionsHtml = '';
      if (story.corrections && story.corrections.length > 0) {
        correctionsHtml = `
          <div style="background:#FEF2F2; border:1px solid #B31942; border-radius:4px; padding:10px; margin-top:10px; font-size:14px; color:#7F1D1D;">
            <strong>OFFICIAL CORRECTION:</strong><br>
            ${story.corrections.map(c => `[${c.date}] ${c.note}`).join('<br>')}
          </div>
        `;
      }

      let imgHtml = '';
      if (story.picture) {
        imgHtml = `<img src="${story.picture}" alt="${story.headline}" class="story-image" loading="lazy" />`;
      }

      card.innerHTML = `
        <div class="story-meta">
          <span class="story-category">${story.category.toUpperCase()}</span>
          <span class="verified-tag">★ VERIFIED SOURCES</span>
        </div>
        <h3>${story.headline}</h3>
        ${imgHtml}
        <p class="story-summary">${story.summary}</p>
        ${correctionsHtml}
        ${sourcesHtml}
      `;
      storiesContainer.appendChild(card);
    });
  }
}

function renderArchive(briefings) {
  const archiveList = document.getElementById('archiveList');
  if (!archiveList) return;

  archiveList.innerHTML = '';
  briefings.forEach((b, idx) => {
    const li = document.createElement('li');
    li.style.marginBottom = '12px';
    li.style.padding = '12px';
    li.style.background = '#FFFFFF';
    li.style.border = '1px solid #E2E8F0';
    li.style.borderRadius = '6px';
    li.style.listStyle = 'none';

    li.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <strong style="color:#0A1931; font-size:16px;">${b.date}</strong>
          <div style="font-size:14px; color:#475569; margin-top:2px;">${b.leadHeadline}</div>
        </div>
        <button onclick="renderBriefing(${idx})" style="background:#0A1931; color:#FFFFFF; border:none; padding:8px 14px; border-radius:4px; cursor:pointer; font-weight:bold;">
          Open Edition
        </button>
      </div>
    `;
    archiveList.appendChild(li);
  });
}
