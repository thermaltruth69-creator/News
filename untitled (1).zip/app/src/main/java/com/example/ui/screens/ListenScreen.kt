package com.example.ui.screens

import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DailyBriefing
import com.example.ui.theme.AmericanRed
import com.example.ui.theme.GoldSeal
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import kotlinx.coroutines.delay

@Composable
fun ListenScreen(
    briefing: DailyBriefing?,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var isPlaying by remember { mutableStateOf(false) }
    var currentProgressSeconds by remember { mutableIntStateOf(142) } // sample start: 2m 22s
    val totalDurationSeconds = remember(briefing) {
        val parts = (briefing?.podcastDuration ?: "18:45").split(":")
        val mins = parts.getOrNull(0)?.toIntOrNull() ?: 18
        val secs = parts.getOrNull(1)?.toIntOrNull() ?: 45
        (mins * 60) + secs
    }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    // Simulated playback ticker for smooth interactive audio UI
    LaunchedEffect(isPlaying, playbackSpeed) {
        while (isPlaying) {
            delay((1000 / playbackSpeed).toLong())
            if (currentProgressSeconds < totalDurationSeconds) {
                currentProgressSeconds += 1
            } else {
                isPlaying = false
            }
        }
    }

    fun formatTime(totalSec: Int): String {
        val m = totalSec / 60
        val s = totalSec % 60
        return String.format("%02d:%02d", m, s)
    }

    if (briefing == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No podcast briefing loaded.")
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("listen_screen_content"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Badge
        Surface(
            color = NavyPrimary,
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                text = "DAILY AUDIO PODCAST",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "True News America Audio Briefing",
            style = MaterialTheme.typography.headlineMedium,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary,
            textAlign = TextAlign.Center
        )

        Text(
            text = briefing.date,
            style = MaterialTheme.typography.titleMedium,
            color = AmericanRed,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Large Player Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("podcast_player_card"),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Microphone / Waves Icon
                Surface(
                    shape = CircleShape,
                    color = NavyContainer,
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = "Podcast",
                            tint = GoldSeal,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = briefing.leadHeadline,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Text(
                    text = "Produced daily in Google NotebookLM with verified sources",
                    style = MaterialTheme.typography.bodySmall,
                    color = GoldSeal,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Progress Slider
                val progressFraction = (currentProgressSeconds.toFloat() / totalDurationSeconds.toFloat()).coerceIn(0f, 1f)
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        currentProgressSeconds = (frac * totalDurationSeconds).toInt()
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = AmericanRed,
                        activeTrackColor = AmericanRed,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("podcast_scrubber_slider")
                )

                // Time labels
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTime(currentProgressSeconds),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "-${formatTime(totalDurationSeconds - currentProgressSeconds)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Big Easy Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Skip back 15s
                    IconButton(
                        onClick = {
                            currentProgressSeconds = (currentProgressSeconds - 15).coerceAtLeast(0)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("skip_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Skip Back 15 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Main Big Play/Pause Button (64dp accessible button)
                    Surface(
                        shape = CircleShape,
                        color = AmericanRed,
                        modifier = Modifier.size(72.dp)
                    ) {
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("big_podcast_play_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause Podcast" else "Play Podcast",
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }

                    // Skip forward 15s
                    IconButton(
                        onClick = {
                            currentProgressSeconds = (currentProgressSeconds + 15).coerceAtMost(totalDurationSeconds)
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("skip_forward_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward10,
                            contentDescription = "Skip Forward 15 Seconds",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Speed Selector Pill
                FilledTonalButton(
                    onClick = {
                        playbackSpeed = when (playbackSpeed) {
                            1.0f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2.0f
                            else -> 1.0f
                        }
                    },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NavyContainer,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("podcast_speed_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Playback Speed",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Speed: ${playbackSpeed}x",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Production Details Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ABOUT THE PODCAST DIVISION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Per our Charter: A daily audio briefing (15–25 minutes) for listeners on the go. Generated in Google NotebookLM from verified research links and editorial summaries, so Americans can listen on their drive or at work without spin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Episode Chapters
        Text(
            text = "AUDIO BRIEFING CHAPTERS",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        briefing.stories.forEachIndexed { idx, story ->
            val startMin = idx * 4 + 1
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = NavyPrimary,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = String.format("%02d:00", startMin),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = story.headline,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = story.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = AmericanRed
                        )
                    }
                }
            }
        }
    }
}
