package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class BriefingRepository(private val context: Context) {

    private val _briefings = MutableStateFlow<List<DailyBriefing>>(emptyList())
    val briefings: StateFlow<List<DailyBriefing>> = _briefings.asStateFlow()

    private val _selectedBriefing = MutableStateFlow<DailyBriefing?>(null)
    val selectedBriefing: StateFlow<DailyBriefing?> = _selectedBriefing.asStateFlow()

    init {
        loadBriefings()
    }

    fun loadBriefings() {
        try {
            val jsonString = context.assets.open("briefings.json").bufferedReader().use { it.readText() }
            val list = parseBriefingsJson(jsonString)
            _briefings.value = list
            if (list.isNotEmpty() && _selectedBriefing.value == null) {
                _selectedBriefing.value = list.first()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback sample in case of asset read issue
            val fallback = createFallbackBriefing()
            _briefings.value = listOf(fallback)
            _selectedBriefing.value = fallback
        }
    }

    fun selectBriefing(briefing: DailyBriefing) {
        _selectedBriefing.value = briefing
    }

    fun addCustomBriefing(newBriefing: DailyBriefing) {
        val current = _briefings.value.toMutableList()
        // Insert at beginning (newest first)
        current.add(0, newBriefing)
        _briefings.value = current
        _selectedBriefing.value = newBriefing
    }

    private fun parseBriefingsJson(jsonString: String): List<DailyBriefing> {
        val array = JSONArray(jsonString)
        val result = mutableListOf<DailyBriefing>()

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val storiesList = mutableListOf<NewsStory>()

            if (obj.has("stories")) {
                val storiesArray = obj.getJSONArray("stories")
                for (j in 0 until storiesArray.length()) {
                    val sObj = storiesArray.getJSONObject(j)
                    val sourcesList = mutableListOf<NewsSource>()
                    if (sObj.has("sources")) {
                        val srcArray = sObj.getJSONArray("sources")
                        for (k in 0 until srcArray.length()) {
                            val srcObj = srcArray.getJSONObject(k)
                            sourcesList.add(
                                NewsSource(
                                    name = srcObj.optString("name", "Source"),
                                    url = srcObj.optString("url", "#")
                                )
                            )
                        }
                    }

                    val correctionsList = mutableListOf<NewsCorrection>()
                    if (sObj.has("corrections")) {
                        val corrArray = sObj.getJSONArray("corrections")
                        for (k in 0 until corrArray.length()) {
                            val cObj = corrArray.getJSONObject(k)
                            correctionsList.add(
                                NewsCorrection(
                                    date = cObj.optString("date", ""),
                                    note = cObj.optString("note", "")
                                )
                            )
                        }
                    }

                    storiesList.add(
                        NewsStory(
                            id = sObj.optString("id", "story-$j"),
                            headline = sObj.optString("headline", "Verified Story"),
                            category = sObj.optString("category", "General"),
                            summary = sObj.optString("summary", ""),
                            picture = sObj.optString("picture", ""),
                            sources = sourcesList,
                            corrections = correctionsList
                        )
                    )
                }
            }

            result.add(
                DailyBriefing(
                    id = obj.optString("id", "briefing-$i"),
                    date = obj.optString("date", "Today"),
                    isoDate = obj.optString("isoDate", ""),
                    leadHeadline = obj.optString("leadHeadline", "True News America Daily Briefing"),
                    leadSummary = obj.optString("leadSummary", ""),
                    leadCategory = obj.optString("leadCategory", "U.S."),
                    youtubeUrl = obj.optString("youtubeUrl", "https://www.youtube.com"),
                    podcastAudioUrl = obj.optString("podcastAudioUrl", ""),
                    videoDuration = obj.optString("videoDuration", "14:20"),
                    podcastDuration = obj.optString("podcastDuration", "18:45"),
                    pictureUrl = obj.optString("pictureUrl", ""),
                    stories = storiesList
                )
            )
        }
        return result
    }

    private fun createFallbackBriefing(): DailyBriefing {
        return DailyBriefing(
            id = "briefing-fallback",
            date = "Wednesday, October 21, 2026",
            isoDate = "2026-10-21",
            leadHeadline = "True News America: Straight, Verified Daily News for the American People",
            leadSummary = "Welcome to True News America. Built on faith, family, and discipline. Every story cites verifiable sources.",
            leadCategory = "National",
            youtubeUrl = "https://www.youtube.com",
            podcastAudioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            pictureUrl = "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=80",
            stories = emptyList()
        )
    }
}
