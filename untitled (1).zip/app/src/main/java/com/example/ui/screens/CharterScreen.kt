package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CharterScreen(
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4EFE6)) // Historic parchment background
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("charter_screen_content"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Document Frame
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, GoldSealDark, RoundedCornerShape(8.dp))
                .border(6.dp, ParchmentBorder, RoundedCornerShape(8.dp))
                .testTag("charter_document_card"),
            colors = CardDefaults.cardColors(containerColor = ParchmentBg),
            shape = RoundedCornerShape(8.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Header Seal
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        color = NavyPrimary,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Charter Seal",
                                tint = GoldSeal,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "TRUE NEWS AMERICA",
                        style = MaterialTheme.typography.displaySmall,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Black,
                        color = NavyDark,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "FOUNDING CHARTER",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = AmericanRed,
                        letterSpacing = 1.5.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "AN AMERICAN OWNED • VETERAN OWNED • FAMILY OWNED NEWS COMPANY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Decorative divider
                    Divider(color = GoldSealDark, thickness = 1.5.dp)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Charter Body — EXACT FULL TEXT WORD FOR WORD
                CharterSectionHeader("Who We Are")
                CharterBodyText(
                    "True News America is an American owned, American run, veteran owned, family owned news company. It was founded by James Hastings Sr., a United States veteran and the company's majority owner (51%), and is built and run day to day with his son, James Hastings.\n\n" +
                    "We are a professional, law-abiding company. We do our work peacefully, openly, and within the law — through faith, family, hard work, and honest debate. That is who we are, and this charter is published so anyone can read exactly what we stand for.\n\n" +
                    "We are not for sale. We will not sell out to corporations, advertisers, or outside interests, and we will not change what we believe for money, pressure, or popularity."
                )

                CharterSectionHeader("Our Family's Companies")
                CharterBodyText(
                    "In full transparency: our family also owns 420 Robotics and Apex Directorate, and the beliefs in this charter are the same beliefs those companies stand on. True News America is still its own brand, run under its own charter and its own decisions.\n\n" +
                    "• Apex Directorate is our family's security and cybersecurity company, and serves as a watchdog group for AI and robotics — testing new technology, watching for risks, and speaking plainly about what it finds. It is veteran owned and family run, it hires veterans, and it is governed by a six-member board made up of family members and church pastor leaders.\n\n" +
                    "• 420 Robotics is our family's robotics company, building open technology in America under the same values.\n\n" +
                    "The right to withhold technology: Our family reserves the right — and accepts the duty — to withhold, pause, or refuse to release any AI system or other technology that our testing shows is dangerous, not ready, or open to misuse. No product, deadline, or payment comes before public safety. This principle comes out of our ongoing work testing and evaluating advanced AI systems, and it applies across all of our companies."
                )

                CharterSectionHeader("Mission")
                CharterBodyText(
                    "Deliver straight, verified news to the American people — lawfully, ethically, and with discipline. Serve faith and humanity: every story shows its sources, so any reader can check our work for themselves."
                )

                CharterSectionHeader("Core Doctrine")
                CharterBodyText(
                    "Tell the truth. Never mislead the public. Publish only what can be verified, correct mistakes openly, and separate fact from opinion. Freedom of the press is a responsibility, not a gift. We answer to God, to our conscience, and to our readers. We do not ask permission to hold our beliefs, and we do not trade them away."
                )

                CharterSectionHeader("Where We Stand — In The Open")
                CharterBodyText(
                    "• Christian faith: We are Christians of the Protestant faith. Our faith in God guides how we work, how we treat people, and what we publish.\n\n" +
                    "• America: We are Americans, America first. We support the Constitution, the rule of law, free speech, and the American people over foreign, corporate, or political interests.\n\n" +
                    "• Veterans: This is a veteran owned company, built on service before self, duty, honor, courage, and sacrifice. We honor the men and women who served this country, we hire veterans in our companies, and we stand with them.\n\n" +
                    "• The Movement: We openly support the MAGA movement and America First principles, and we are supporters of Turning Point USA and its mission to educate and activate Americans in faith, freedom, and love of country.\n\n" +
                    "• No sellouts: No advertiser, sponsor, platform, donor, or corporation can buy our coverage or change a story. If money and truth ever conflict, truth wins and the money goes."
                )

                CharterSectionHeader("The Triad of Conviction")

                CharterSubHeader("1. Nation and Law (public principles)")
                CharterBodyText(
                    "• Respect the Constitution and the rule of law.\n" +
                    "• Protect free speech and open debate.\n" +
                    "• Put the safety of people ahead of profit or ego.\n" +
                    "• Be honest with readers, sources, and the public.\n" +
                    "• Every claim links to a source a reader can verify."
                )

                CharterSubHeader("2. Faith and Family (cultural principles)")
                CharterBodyText(
                    "• Faith in God guides conduct, and every person is treated with dignity.\n" +
                    "• We hold Christian Protestant beliefs and we state them openly.\n" +
                    "• Life is valued and protected.\n" +
                    "• Family comes first, and the work supports the home.\n" +
                    "• Learn constantly and favor truth over trends.\n" +
                    "• Serve the community, not just the company."
                )

                CharterSubHeader("3. Personal Discipline (individual principles)")
                CharterBodyText(
                    "• Take ownership and don't blame others.\n" +
                    "• Do the hard thing early.\n" +
                    "• Keep your word.\n" +
                    "• Lead by example.\n" +
                    "• Speak plainly and respectfully, even when it costs you.\n" +
                    "• Finish the mission. Duty first, excuses never."
                )

                CharterSectionHeader("Governance")
                CharterBodyText(
                    "• James Hastings Sr.: Founder, majority owner (51%), veteran, and Publisher. Sets editorial standards, holds final review and final say on publishing decisions.\n\n" +
                    "• James Hastings: Builds and runs the production and technology — research systems, video, podcast, and the website — working for and with his dad to run the company day to day.\n\n" +
                    "• Board: A board of five (5) people governs major decisions for True News America. Major decisions are put to a board vote and the majority carries. The board also reviews ethics questions and major commitments before they are made.\n\n" +
                    "• Succession: A written succession plan covers each key role."
                )

                CharterSectionHeader("Divisions")
                CharterBodyText(
                    "• Daily Briefing: The day's verified news events, written plainly, with sources linked on the page.\n\n" +
                    "• Video Briefing: A daily video slideshow (10–18 minutes) presenting the day's briefing.\n\n" +
                    "• Podcast: A daily audio briefing (15–25 minutes) for listeners on the go.\n\n" +
                    "• Research & Fact-Checking: Online news research, source verification, and link checking before anything is published."
                )

                CharterSectionHeader("Public Posture")
                CharterBodyText(
                    "Public materials (the True News America website, YouTube channel, and Facebook page) describe the work as straight news, verified sourcing, and honest corrections — and they state our beliefs openly, the same as this charter. Internal and public language should say the same thing. We hide nothing about who we are."
                )

                CharterSectionHeader("Operations")
                CharterBodyText(
                    "Daily news briefings, weekly editorial reviews, monthly ethics reviews, and a standing corrections process: any error found is fixed on the page, noted openly, and the correction is dated. Sources are saved with each day's briefing so the record behind every story can be re-checked. No paid story placements, no sponsored opinions, and no coverage decisions made by anyone outside this charter."
                )

                Spacer(modifier = Modifier.height(24.dp))
                Divider(color = GoldSealDark, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Signatures Box
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "James Hastings Sr.",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Text(
                            text = "Founder, Majority Owner (51%), Veteran & Publisher",
                            style = MaterialTheme.typography.labelSmall,
                            color = ParchmentInk
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "James Hastings",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Text(
                            text = "Production, Technology & Operations",
                            style = MaterialTheme.typography.labelSmall,
                            color = ParchmentInk
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CharterSectionHeader(title: String) {
    Spacer(modifier = Modifier.height(18.dp))
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        color = NavyDark
    )
    Spacer(modifier = Modifier.height(6.dp))
}

@Composable
private fun CharterSubHeader(title: String) {
    Spacer(modifier = Modifier.height(10.dp))
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = AmericanRed
    )
    Spacer(modifier = Modifier.height(4.dp))
}

@Composable
private fun CharterBodyText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        fontFamily = FontFamily.Serif,
        color = ParchmentInk,
        lineHeight = 27.sp
    )
}
