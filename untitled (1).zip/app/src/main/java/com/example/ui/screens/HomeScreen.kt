package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.DailyBriefing
import com.example.data.NewsStory
import com.example.ui.components.StoryCard
import com.example.ui.components.StoryDetailDialog
import com.example.ui.theme.AmericanRed
import com.example.ui.theme.GoldSeal
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary

@Composable
fun HomeScreen(
    briefing: DailyBriefing?,
    onNavigateToWatch: () -> Unit,
    onNavigateToListen: () -> Unit,
    onNavigateToCharter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedStoryForDetail by remember { mutableStateOf<NewsStory?>(null) }

    if (briefing == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = NavyPrimary)
        }
        return
    }

    val categories = remember(briefing) {
        val cats = briefing.stories.map { it.category }.distinct().toMutableList()
        cats.add(0, "All")
        cats
    }

    val filteredStories = remember(briefing, selectedCategory) {
        if (selectedCategory == "All") {
            briefing.stories
        } else {
            briefing.stories.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TOP STORY HERO BANNER
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("hero_top_story_card"),
                colors = CardDefaults.cardColors(containerColor = NavyDark),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Badge row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = AmericanRed,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "TODAY'S TOP STORY",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.8.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Lead",
                                tint = GoldSeal,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = briefing.leadCategory.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldSeal,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Lead headline
                    Text(
                        text = briefing.leadHeadline,
                        style = MaterialTheme.typography.headlineMedium,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        lineHeight = 28.sp,
                        modifier = Modifier.testTag("hero_lead_headline")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Picture
                    if (briefing.pictureUrl.isNotBlank()) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(briefing.pictureUrl)
                                .crossfade(true)
                                .build(),
                            contentDescription = briefing.leadHeadline,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Lead summary
                    Text(
                        text = briefing.leadSummary,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action buttons: Watch Video + Listen to Podcast
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onNavigateToWatch,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("hero_watch_video_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = AmericanRed),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PlayCircle, contentDescription = "Watch Video")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Watch Video (${briefing.videoDuration})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Button(
                            onClick = onNavigateToListen,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("hero_listen_podcast_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = NavyContainer),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Headphones, contentDescription = "Listen Podcast")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Listen Podcast (${briefing.podcastDuration})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Section Title: TODAY'S STORIES
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "TODAY'S VERIFIED STORIES",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Text(
                    text = "Every story links directly to verified public sources and primary documents.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Category Filter Chips
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = (cat == selectedCategory)
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = {
                            Text(
                                text = cat,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_chip_$cat")
                    )
                }
            }
        }

        // List of stories
        items(filteredStories, key = { it.id }) { story ->
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                StoryCard(
                    story = story,
                    onStoryClick = { selectedStoryForDetail = story }
                )
            }
        }

        // Charter Banner Footer
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable(onClick = onNavigateToCharter)
                    .testTag("home_charter_footer_card"),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFF1F5F9)
                ),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldSeal.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "★ OUR CHARTER PLEDGE ★",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmericanRed,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "\"Deliver straight, verified news to the American people — lawfully, ethically, and with discipline. Freedom of the press is a responsibility, not a gift.\"",
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Serif,
                        color = NavyPrimary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Read the Full Founding Charter →",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = AmericanRed
                    )
                }
            }
        }
    }

    // Detail Dialog if opened
    selectedStoryForDetail?.let { story ->
        StoryDetailDialog(
            story = story,
            dateString = briefing.date,
            onDismiss = { selectedStoryForDetail = null }
        )
    }
}
