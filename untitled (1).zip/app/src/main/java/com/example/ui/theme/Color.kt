package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// True News America — Professional American Newspaper Palette
val NavyPrimary = Color(0xFF0A1931)
val NavySecondary = Color(0xFF152A52)
val NavyContainer = Color(0xFF1E3A70)
val NavyDark = Color(0xFF060E1A)

val AmericanRed = Color(0xFFB31942)
val AmericanRedDark = Color(0xFF8B1032)
val AmericanRedLight = Color(0xFFD6335B)

val GoldSeal = Color(0xFFC5A059)
val GoldSealLight = Color(0xFFE2C889)
val GoldSealDark = Color(0xFF8C6F34)

val NewsPaperWhite = Color(0xFFFAF9F6)
val NewsPaperPaper = Color(0xFFF3F2EC)
val NewsPaperCard = Color(0xFFFFFFFF)

val NewsInkDark = Color(0xFF0F172A)
val NewsInkMuted = Color(0xFF475569)
val NewsInkLight = Color(0xFF64748B)

val ParchmentBg = Color(0xFFF7F4EB)
val ParchmentBorder = Color(0xFFDACFBD)
val ParchmentInk = Color(0xFF2C2416)
