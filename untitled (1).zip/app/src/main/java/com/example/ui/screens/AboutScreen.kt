package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun AboutScreen(
    onNavigateToCharter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("about_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Column {
            Surface(
                color = AmericanRed,
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "WHO WE ARE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Built on Faith, Family, and American Veteran Service",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "A father and son founded this news company to bring straight, verified facts back to the American people.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // MANDATORY WORD-FOR-WORD BANNER
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, GoldSeal, RoundedCornerShape(8.dp))
                .testTag("mandatory_ownership_statement_card"),
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "★ OFFICIAL OWNERSHIP DISCLOSURE ★",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldSeal,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                // EXACT REQUIRED LINE WORD-FOR-WORD:
                Text(
                    text = "True News America is an independent, American, veteran owned, family-owned news company. Its owners also own 420 Robotics and Apex Directorate. True News America is its own brand, run under its own charter.",
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = 24.sp
                )
            }
        }

        // Founders Section
        Text(
            text = "OUR LEADERSHIP",
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Surface(
                        color = NavyPrimary,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MilitaryTech,
                                contentDescription = "Veteran",
                                tint = GoldSeal
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "James Hastings Sr.",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "Founder, 51% Owner & Publisher",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmericanRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "United States military veteran. Holds majority ownership, sets editorial discipline, and holds final say on all publishing decisions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Surface(
                        color = NavyContainer,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.FamilyRestroom,
                                contentDescription = "Family",
                                tint = Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "James Hastings",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "Production & Technology",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmericanRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Builds and runs production, fact-checking systems, video slideshows, podcast audio, and the website, working day to day with his dad.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Where We Stand List
        Text(
            text = "WHERE WE STAND — IN THE OPEN",
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        StandCard(
            title = "Christian Faith",
            desc = "We are Christians of the Protestant faith. Our faith in God guides how we work, how we treat people, and what we publish."
        )

        StandCard(
            title = "America First & Constitution",
            desc = "We are Americans, America first. We support the Constitution, the rule of law, free speech, and the American people over foreign, corporate, or political interests."
        )

        StandCard(
            title = "Honoring Veterans",
            desc = "This is a veteran owned company, built on service before self, duty, honor, courage, and sacrifice. We honor the men and women who served this country, we hire veterans in our companies, and we stand with them."
        )

        StandCard(
            title = "The Movement",
            desc = "We openly support the MAGA movement and America First principles, and we are supporters of Turning Point USA and its mission to educate and activate Americans in faith, freedom, and love of country."
        )

        StandCard(
            title = "No Sellouts",
            desc = "No advertiser, sponsor, platform, donor, or corporation can buy our coverage or change a story. If money and truth ever conflict, truth wins and the money goes."
        )

        // Family Companies
        Text(
            text = "OUR FAMILY'S COMPANIES",
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        CompanyCard(
            icon = Icons.Default.Security,
            name = "Apex Directorate",
            role = "Security, Cybersecurity & AI Watchdog",
            desc = "Our family's security and cybersecurity company, and serves as a watchdog group for AI and robotics — testing new technology, watching for risks, and speaking plainly about what it finds. Veteran owned, family run, hires veterans, and governed by a six-member board of family members and church pastor leaders."
        )

        CompanyCard(
            icon = Icons.Default.SmartToy,
            name = "420 Robotics",
            role = "American Open Robotics",
            desc = "Our family's robotics company, building open technology in America under the same values."
        )

        // Duty to Withhold Dangerous Tech Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, AmericanRed.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "THE RIGHT TO WITHHOLD TECHNOLOGY",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = AmericanRed
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Our family reserves the right — and accepts the duty — to withhold, pause, or refuse to release any AI system or other technology that our testing shows is dangerous, not ready, or open to misuse. No product, deadline, or payment comes before public safety.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF7F1D1D),
                    lineHeight = 22.sp
                )
            }
        }

        // Charter CTA
        Button(
            onClick = onNavigateToCharter,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("about_view_charter_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text("Read Our Full Founding Charter Document", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StandCard(title: String, desc: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(6.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "• $title",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AmericanRed
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun CompanyCard(
    icon: ImageVector,
    name: String,
    role: String,
    desc: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(6.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                color = NavyContainer,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = name,
                        tint = GoldSeal,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Text(
                    text = role,
                    style = MaterialTheme.typography.labelSmall,
                    color = AmericanRed,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }
    }
}
