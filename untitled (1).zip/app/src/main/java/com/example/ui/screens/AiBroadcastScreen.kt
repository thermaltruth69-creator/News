package com.example.ui.screens

import android.content.Context
import android.graphics.BitmapFactory
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Locale

data class BroadcastSegment(
    val title: String,
    val tickerTopic: String,
    val speechScript: String,
    val statsTitle: String,
    val statsSubtitle: String,
    val statValues: List<Pair<String, String>>,
    val statPercents: List<Float>
)

@Composable
fun AiBroadcastScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Load local news anchor bitmap from assets
    val anchorBitmap = remember {
        try {
            context.assets.open("news_anchor.jpg").use { inputStream ->
                BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: Exception) {
            null
        }
    }

    // Segments based directly on the attached Charter PDF
    val segments = remember {
        listOf(
            BroadcastSegment(
                title = "INTRODUCTION: FOUNDING & MISSION",
                tickerTopic = "TRUE NEWS AMERICA CHARTER SPECIAL REPORT",
                speechScript = "Good evening and welcome to True News America. I am your broadcast anchor presenting our founding charter. True News America was established by United States veteran James Hastings Senior and his son James Hastings with a singular mission: deliver straight, verified news to the American people, lawfully, ethically, and with complete discipline. Every single story shows its sources so you can verify the facts for yourself.",
                statsTitle = "EDITORIAL CREDIBILITY MANDATE",
                statsSubtitle = "Zero Corporate or Advertiser Influence",
                statValues = listOf(
                    "Primary Sourcing" to "100% Verified",
                    "Sponsored Opinions" to "0% Allowed",
                    "Public Verification" to "Every Claim"
                ),
                statPercents = listOf(1.0f, 0.0f, 1.0f)
            ),
            BroadcastSegment(
                title = "BODY PART 1: OWNERSHIP & AI WATCHDOG",
                tickerTopic = "OWNERSHIP: 51% VETERAN OWNED • APEX DIRECTORATE WATCHDOG",
                speechScript = "In our ownership structure, James Hastings Senior holds fifty-one percent majority ownership as a veteran and publisher. In full transparency, our family also operates Apex Directorate, a cybersecurity and robotics watchdog group governed by church pastors and family leaders. Under our charter, our family reserves the right and duty to withhold any dangerous AI or robotics system before it can harm the public.",
                statsTitle = "OWNERSHIP & GOVERNANCE STRUCTURE",
                statsSubtitle = "Independent Veteran & Family Majority Control",
                statValues = listOf(
                    "James Hastings Sr. (Veteran & Publisher)" to "51% Equity",
                    "Family Operations (James Hastings)" to "49% Equity",
                    "Apex Directorate Watchdog Board" to "6 Members (Pastors & Family)"
                ),
                statPercents = listOf(0.51f, 0.49f, 0.60f)
            ),
            BroadcastSegment(
                title = "BODY PART 2: THE TRIAD OF CONVICTION",
                tickerTopic = "OUR PILLARS: NATION & LAW • FAITH & FAMILY • PERSONAL DISCIPLINE",
                speechScript = "Our convictions stand on three pillars. First, Nation and Law: upholding the Constitution, protecting free speech, and putting public safety over profit. Second, Faith and Family: honoring our Protestant Christian beliefs, valuing human life, and serving the community. And third, Personal Discipline: duty first, leading by example, and never making excuses.",
                statsTitle = "THE TRIAD OF CONVICTION",
                statsSubtitle = "Three Non-Negotiable Operational Pillars",
                statValues = listOf(
                    "Pillar 1: Nation and Law" to "Constitutional Rule of Law",
                    "Pillar 2: Faith and Family" to "Christian Protestant Ethics",
                    "Pillar 3: Personal Discipline" to "Service Before Self"
                ),
                statPercents = listOf(1.0f, 1.0f, 1.0f)
            ),
            BroadcastSegment(
                title = "BODY PART 3: DAILY PRODUCTION METRICS",
                tickerTopic = "DAILY BROADCAST: 10-18 MIN VIDEO • 15-25 MIN NOTEBOOKLM PODCAST",
                speechScript = "Every day, our newsroom produces three primary divisions: a concise verified Daily Briefing, a ten to eighteen minute video slideshow, and a fifteen to twenty-five minute audio podcast created in Google NotebookLM for listeners on the go. Any error found is corrected openly on the page with an explicit timestamp and date.",
                statsTitle = "DAILY PRODUCTION OUTPUT",
                statsSubtitle = "Synchronized Multi-Format Briefings",
                statValues = listOf(
                    "Video Slideshow Length" to "10–18 Minutes",
                    "Audio Podcast Briefing" to "15–25 Minutes",
                    "Corrections Policy" to "Open & Dated"
                ),
                statPercents = listOf(0.70f, 0.85f, 1.0f)
            ),
            BroadcastSegment(
                title = "CONCLUSION: THE PLEDGE TO AMERICA",
                tickerTopic = "FREEDOM OF THE PRESS IS A RESPONSIBILITY, NOT A GIFT",
                speechScript = "We conclude with our founding pledge: Freedom of the press is a responsibility, not a gift. We answer to God, to our conscience, and to our readers. We do not ask permission to hold our beliefs, and we do not trade them away. Thank you for trusting True News America. Straight, verified news for the American people.",
                statsTitle = "FOUNDING PRINCIPLE CONCLUSION",
                statsSubtitle = "The True News America Public Guarantee",
                statValues = listOf(
                    "Commitment to Truth" to "Absolute",
                    "Outside Buyouts" to "Not For Sale",
                    "Accountability" to "To God & Readers"
                ),
                statPercents = listOf(1.0f, 0.0f, 1.0f)
            )
        )
    }

    var currentSegmentIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var speechRate by remember { mutableFloatStateOf(1.0f) }
    var isTtsReady by remember { mutableStateOf(false) }

    // Android TextToSpeech engine
    var tts: TextToSpeech? by remember { mutableStateOf(null) }

    DisposableEffect(Unit) {
        val ttsInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                isTtsReady = true
            }
        }
        ttsInstance.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isPlaying = true
            }

            override fun onDone(utteranceId: String?) {
                if (currentSegmentIndex < segments.size - 1) {
                    currentSegmentIndex += 1
                } else {
                    isPlaying = false
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                isPlaying = false
            }
        })
        tts = ttsInstance

        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    // Function to speak segment
    fun speakCurrentSegment() {
        val seg = segments[currentSegmentIndex]
        tts?.setSpeechRate(speechRate)
        tts?.speak(seg.speechScript, TextToSpeech.QUEUE_FLUSH, null, "segment-$currentSegmentIndex")
        isPlaying = true
    }

    fun stopSpeaking() {
        tts?.stop()
        isPlaying = false
    }

    LaunchedEffect(currentSegmentIndex) {
        if (isPlaying) {
            speakCurrentSegment()
        }
    }

    val activeSegment = segments[currentSegmentIndex]

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("ai_broadcast_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Broadcast Top Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = AmericanRed,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(8.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE ANCHOR BROADCAST",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }

            Text(
                text = "Segment ${currentSegmentIndex + 1} of ${segments.size}",
                style = MaterialTheme.typography.labelMedium,
                color = GoldSeal,
                fontWeight = FontWeight.Bold
            )
        }

        // News Studio Anchor Video Frame
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, GoldSeal.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                .testTag("broadcast_video_frame_card"),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                if (anchorBitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = anchorBitmap.asImageBitmap(),
                        contentDescription = "AI News Anchor at True News America desk",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(NavyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "TRUE NEWS AMERICA\nBROADCAST STUDIO",
                            fontFamily = FontFamily.Serif,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Overlay gradient for lower third
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.2f),
                                    Color.Black.copy(alpha = 0.95f)
                                ),
                                startY = 100f
                            )
                        )
                )

                // Top Left Live Bug
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopStart)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Camera",
                            tint = AmericanRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "TNA STUDIO 1 • WASHINGTON",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Dynamic Animated Lower-Third Graphic Banner
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    NavyPrimary.copy(alpha = 0.85f),
                                    NavyDark
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.horizontalGradient(listOf(AmericanRed, GoldSeal, AmericanRed)),
                            shape = RoundedCornerShape(0.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = AmericanRed,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = "SPECIAL REPORT",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "CHARTER VERIFICATION",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldSeal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activeSegment.tickerTopic,
                        style = MaterialTheme.typography.titleSmall,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Big Audio/Voice Broadcast Controls
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E38)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = activeSegment.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GoldSeal,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Previous segment
                    IconButton(
                        onClick = {
                            if (currentSegmentIndex > 0) {
                                currentSegmentIndex--
                            }
                        },
                        enabled = currentSegmentIndex > 0,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous Segment",
                            tint = if (currentSegmentIndex > 0) Color.White else Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Main Big Broadcast Voice Play/Pause
                    Surface(
                        shape = CircleShape,
                        color = if (isPlaying) AmericanRed else GoldSeal,
                        modifier = Modifier.size(68.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (isPlaying) {
                                    stopSpeaking()
                                } else {
                                    speakCurrentSegment()
                                }
                            },
                            modifier = Modifier.fillMaxSize().testTag("anchor_voice_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause Anchor Voice" else "Deliver Report Aloud",
                                tint = NavyDark,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    // Next segment
                    IconButton(
                        onClick = {
                            if (currentSegmentIndex < segments.size - 1) {
                                currentSegmentIndex++
                            }
                        },
                        enabled = currentSegmentIndex < segments.size - 1,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next Segment",
                            tint = if (currentSegmentIndex < segments.size - 1) Color.White else Color.Gray,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Voice speed toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isPlaying) "Anchor is speaking aloud..." else "Tap to hear Anchor report aloud",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isPlaying) Color(0xFF4ADE80) else Color.White.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    TextButton(
                        onClick = {
                            speechRate = when (speechRate) {
                                1.0f -> 1.15f
                                1.15f -> 0.9f
                                else -> 1.0f
                            }
                            if (isPlaying) speakCurrentSegment()
                        }
                    ) {
                        Text(
                            text = "${speechRate}x Speed",
                            color = GoldSeal,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic Motion Graphics & Data Visualizations Card (from PDF Charter)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NavyContainer, RoundedCornerShape(10.dp))
                .testTag("broadcast_stats_card"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF132247)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = "Statistics",
                        tint = GoldSeal,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = activeSegment.statsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = activeSegment.statsSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = GoldSealLight
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Visual Bars and Metrics
                activeSegment.statValues.forEachIndexed { i, stat ->
                    val progress = activeSegment.statPercents.getOrElse(i) { 1.0f }
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stat.first,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = stat.second,
                                style = MaterialTheme.typography.bodyMedium,
                                color = GoldSeal,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = when (i % 3) {
                                0 -> AmericanRed
                                1 -> GoldSeal
                                else -> Color(0xFF38BDF8)
                            },
                            trackColor = Color.White.copy(alpha = 0.15f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Teleprompter / Report Transcript
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1426)),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = "Teleprompter",
                        tint = GoldSeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ANCHOR SCRIPT & TELEPROMPTER",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldSeal,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "\"${activeSegment.speechScript}\"",
                    style = MaterialTheme.typography.bodyLarge,
                    fontFamily = FontFamily.Serif,
                    color = Color.White.copy(alpha = 0.95f),
                    lineHeight = 26.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Segment Selector Pills
        Text(
            text = "BROADCAST SEGMENTS",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = GoldSeal,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        segments.forEachIndexed { index, seg ->
            val isCurrent = (index == currentSegmentIndex)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable {
                        currentSegmentIndex = index
                        if (isPlaying) speakCurrentSegment()
                    },
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) NavyPrimary else Color(0xFF0F1E38)
                ),
                shape = RoundedCornerShape(6.dp),
                border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, GoldSeal) else null
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (isCurrent) AmericanRed else NavyDark,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "${index + 1}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = seg.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isCurrent) GoldSeal else Color.White
                        )
                        Text(
                            text = seg.statsSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    if (isCurrent && isPlaying) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Playing",
                            tint = Color(0xFF4ADE80),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
