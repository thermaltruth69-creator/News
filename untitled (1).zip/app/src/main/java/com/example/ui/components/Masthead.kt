package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmericanRed
import com.example.ui.theme.GoldSeal
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary

@Composable
fun Masthead(
    dateText: String,
    onNavigateToCharter: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToSourcing: () -> Unit,
    onNavigateToManager: () -> Unit,
    onNavigateToAiBroadcast: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NavyPrimary)
    ) {
        // Top Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyDark)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AMERICAN OWNED • VETERAN OWNED • FAMILY OWNED",
                style = MaterialTheme.typography.labelSmall,
                color = GoldSeal,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                fontSize = 11.sp
            )
            Text(
                text = "★ EST. 2026",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.8f),
                fontWeight = FontWeight.Bold
            )
        }

        // Main Masthead Title
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 8.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "TRUE NEWS AMERICA",
                style = MaterialTheme.typography.displayMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("app_masthead_title")
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Red/Gold decorative line
            Row(
                modifier = Modifier.fillMaxWidth(0.85f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(AmericanRed)
                )
                Text(
                    text = " ★ VERIFIED NEWS ★ ",
                    color = GoldSeal,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(AmericanRed)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = dateText,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.95f),
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("masthead_date_text")
            )
        }

        // Quick Links Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White.copy(alpha = 0.08f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderNavLink(
                title = "AI Anchor",
                icon = Icons.Default.SmartToy,
                onClick = onNavigateToAiBroadcast,
                tag = "nav_link_ai_broadcast"
            )
            HeaderNavLink(
                title = "Charter",
                icon = Icons.Default.Description,
                onClick = onNavigateToCharter,
                tag = "nav_link_charter"
            )
            HeaderNavLink(
                title = "About",
                icon = Icons.Default.Info,
                onClick = onNavigateToAbout,
                tag = "nav_link_about"
            )
            HeaderNavLink(
                title = "Sourcing",
                icon = Icons.Default.Verified,
                onClick = onNavigateToSourcing,
                tag = "nav_link_sourcing"
            )
            HeaderNavLink(
                title = "New Day",
                icon = Icons.Default.Edit,
                onClick = onNavigateToManager,
                tag = "nav_link_manager"
            )
        }
    }
}

@Composable
private fun HeaderNavLink(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = GoldSeal,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}
