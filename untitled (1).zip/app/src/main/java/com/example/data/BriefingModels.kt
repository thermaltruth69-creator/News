package com.example.data

data class NewsSource(
    val name: String,
    val url: String
)

data class NewsCorrection(
    val date: String,
    val note: String
)

data class NewsStory(
    val id: String,
    val headline: String,
    val category: String,
    val summary: String,
    val picture: String,
    val sources: List<NewsSource> = emptyList(),
    val corrections: List<NewsCorrection> = emptyList()
)

data class DailyBriefing(
    val id: String,
    val date: String,
    val isoDate: String,
    val leadHeadline: String,
    val leadSummary: String,
    val leadCategory: String,
    val youtubeUrl: String,
    val podcastAudioUrl: String,
    val videoDuration: String = "14:20",
    val podcastDuration: String = "18:45",
    val pictureUrl: String,
    val stories: List<NewsStory> = emptyList()
)
