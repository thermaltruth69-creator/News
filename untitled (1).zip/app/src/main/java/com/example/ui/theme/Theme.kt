package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = NavyContainer,
    onPrimaryContainer = Color.White,
    secondary = AmericanRed,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDAD9),
    onSecondaryContainer = AmericanRedDark,
    tertiary = GoldSeal,
    onTertiary = NavyDark,
    tertiaryContainer = GoldSealLight,
    onTertiaryContainer = GoldSealDark,
    background = NewsPaperWhite,
    onBackground = NewsInkDark,
    surface = NewsPaperCard,
    onSurface = NewsInkDark,
    surfaceVariant = NewsPaperPaper,
    onSurfaceVariant = NewsInkMuted,
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90B4EE),
    onPrimary = NavyDark,
    primaryContainer = NavySecondary,
    onPrimaryContainer = Color.White,
    secondary = AmericanRedLight,
    onSecondary = Color.White,
    secondaryContainer = AmericanRedDark,
    onSecondaryContainer = Color.White,
    tertiary = GoldSealLight,
    onTertiary = NavyDark,
    background = NavyDark,
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF0F1E38),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF162544),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF334155),
    outlineVariant = Color(0xFF1E293B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent American newspaper branding
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
