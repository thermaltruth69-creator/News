package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BriefingRepository
import com.example.ui.components.Masthead
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class AppScreen(val title: String) {
    HOME("Home"),
    AI_BROADCAST("AI Anchor"),
    WATCH("Watch"),
    LISTEN("Listen"),
    ARCHIVE("Archive"),
    CHARTER("Charter"),
    ABOUT("About"),
    SOURCING("Sourcing"),
    MANAGER("Manager")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                TrueNewsAmericaApp()
            }
        }
    }
}

@Composable
fun TrueNewsAmericaApp() {
    val context = LocalContext.current
    val repository = remember { BriefingRepository(context) }

    val briefings by repository.briefings.collectAsStateWithLifecycle()
    val selectedBriefing by repository.selectedBriefing.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    // Handle back press gracefully: return to HOME if on subscreen
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        currentScreen = AppScreen.HOME
    }

    val activeBriefing = selectedBriefing ?: briefings.firstOrNull()
    val dateText = activeBriefing?.date ?: "Wednesday, October 21, 2026"

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            Masthead(
                dateText = dateText,
                onNavigateToCharter = { currentScreen = AppScreen.CHARTER },
                onNavigateToAbout = { currentScreen = AppScreen.ABOUT },
                onNavigateToSourcing = { currentScreen = AppScreen.SOURCING },
                onNavigateToManager = { currentScreen = AppScreen.MANAGER },
                onNavigateToAiBroadcast = { currentScreen = AppScreen.AI_BROADCAST }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = NavyDark,
                contentColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HOME,
                    onClick = { currentScreen = AppScreen.HOME },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyDark,
                        selectedTextColor = GoldSeal,
                        indicatorColor = GoldSeal,
                        unselectedIconColor = Color.White.copy(alpha = 0.7f),
                        unselectedTextColor = Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_item_home")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.AI_BROADCAST,
                    onClick = { currentScreen = AppScreen.AI_BROADCAST },
                    icon = { Icon(Icons.Default.SmartToy, contentDescription = "AI Anchor") },
                    label = { Text("AI Anchor") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyDark,
                        selectedTextColor = GoldSeal,
                        indicatorColor = GoldSeal,
                        unselectedIconColor = Color.White.copy(alpha = 0.7f),
                        unselectedTextColor = Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_item_ai_broadcast")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.WATCH,
                    onClick = { currentScreen = AppScreen.WATCH },
                    icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Watch") },
                    label = { Text("Watch") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyDark,
                        selectedTextColor = GoldSeal,
                        indicatorColor = GoldSeal,
                        unselectedIconColor = Color.White.copy(alpha = 0.7f),
                        unselectedTextColor = Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_item_watch")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.LISTEN,
                    onClick = { currentScreen = AppScreen.LISTEN },
                    icon = { Icon(Icons.Default.Headphones, contentDescription = "Listen") },
                    label = { Text("Listen") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyDark,
                        selectedTextColor = GoldSeal,
                        indicatorColor = GoldSeal,
                        unselectedIconColor = Color.White.copy(alpha = 0.7f),
                        unselectedTextColor = Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_item_listen")
                )

                NavigationBarItem(
                    selected = currentScreen == AppScreen.CHARTER,
                    onClick = { currentScreen = AppScreen.CHARTER },
                    icon = { Icon(Icons.Default.Description, contentDescription = "Charter") },
                    label = { Text("Charter") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyDark,
                        selectedTextColor = GoldSeal,
                        indicatorColor = GoldSeal,
                        unselectedIconColor = Color.White.copy(alpha = 0.7f),
                        unselectedTextColor = Color.White.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.testTag("nav_item_charter")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> HomeScreen(
                    briefing = activeBriefing,
                    onNavigateToWatch = { currentScreen = AppScreen.WATCH },
                    onNavigateToListen = { currentScreen = AppScreen.LISTEN },
                    onNavigateToCharter = { currentScreen = AppScreen.CHARTER }
                )
                AppScreen.AI_BROADCAST -> AiBroadcastScreen()
                AppScreen.WATCH -> WatchScreen(
                    briefing = activeBriefing
                )
                AppScreen.LISTEN -> ListenScreen(
                    briefing = activeBriefing
                )
                AppScreen.ARCHIVE -> ArchiveScreen(
                    briefings = briefings,
                    currentSelectedId = activeBriefing?.id ?: "",
                    onSelectBriefing = { chosen ->
                        repository.selectBriefing(chosen)
                        currentScreen = AppScreen.HOME
                    }
                )
                AppScreen.CHARTER -> CharterScreen()
                AppScreen.ABOUT -> AboutScreen(
                    onNavigateToCharter = { currentScreen = AppScreen.CHARTER }
                )
                AppScreen.SOURCING -> SourcingScreen()
                AppScreen.MANAGER -> BriefingManagerScreen(
                    onBriefingCreated = { newBriefing ->
                        repository.addCustomBriefing(newBriefing)
                        currentScreen = AppScreen.HOME
                    }
                )
            }
        }
    }
}
