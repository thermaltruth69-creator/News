package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmericanRed
import com.example.ui.theme.GoldSeal
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary

@Composable
fun SourcingScreen(
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("sourcing_screen_content"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Surface(
                color = NavyPrimary,
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "STANDARDS & VERIFICATION",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "How We Source Our News",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Every story links to its sources so you can check our work. Mistakes get corrected openly with a date.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 4 Core Principles of Sourcing
        SourcingPillarCard(
            icon = Icons.Default.Link,
            title = "1. Every Claim Links to a Source",
            desc = "We do not ask our readers to take our word for granted. Under every single story in our daily briefing, we provide active links to official government publications, legislative transcripts, court records, economic databases, and verified primary reporting."
        )

        SourcingPillarCard(
            icon = Icons.Default.Verified,
            title = "2. Separation of Fact from Opinion",
            desc = "As ordered in our Founding Charter: Tell the truth. Never mislead the public. Publish only what can be verified. Our daily briefing reports verified events plainly, with zero paid placements, zero sponsored opinions, and zero clickbait sensationalism."
        )

        SourcingPillarCard(
            icon = Icons.Default.History,
            title = "3. Open, Dated Corrections Process",
            desc = "Any error found is fixed on the page immediately, noted openly, and the correction is dated with the exact time. We do not stealth-edit stories or delete history. When we make a mistake, we own it plainly."
        )

        SourcingPillarCard(
            icon = Icons.Default.AssignmentTurnedIn,
            title = "4. Permanent Archival of Records",
            desc = "Sources are preserved with each day's briefing in our archive so the record behind every story can be re-checked weeks, months, or years later by any citizen."
        )

        // Live Corrections Log Sample
        Text(
            text = "STANDING CORRECTIONS LOG",
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AmericanRed.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CORRECTION ENTRY: October 20, 2026 (14:30 EST)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = AmericanRed
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Story: \"Supreme Court Hears Landmark Arguments on State Regulatory Preemption\"",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Clarification: Clarified that petitioner argument was delivered by counsel for state coalitions rather than single municipal entity. Sourcing citations updated with Supreme Court docket transcript No. 25-1104.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Reader Contact Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "EDITORIAL INQUIRIES & CORRECTION REQUESTS",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "If you spot an inaccuracy or broken source link in any briefing, contact our research desk. All correction inquiries are reviewed by James Hastings and Publisher James Hastings Sr.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SourcingPillarCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                color = NavyContainer,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = GoldSeal,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }
        }
    }
}
